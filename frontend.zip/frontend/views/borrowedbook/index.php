<?php

use yii\helpers\Html;
use yii\grid\GridView;
use frontend\models\Student;
use frontend\models\Borrowedbook;
use frontend\models\Book;
/* @var $this yii\web\View */
/* @var $searchModel frontend\models\BorrowedbookSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Borrowedbooks';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="borrowedbook-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Create Borrowedbook', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            [
              'attribute' => 'bbId',
              'value' => function ($dataProvider) {
                  $borrowedName = Book::find()->where(['bookId'=>$dataProvider->bookId])->One();
                  return $borrowedName->bookName;
              },
            ],
            [
              'attribute' => 'studentId',
              'value' => function ($dataProvider) {
                  $studentName = Student::find()->where(['studentsId'=>$dataProvider->studentId])->One();
                  return $studentName->fullName;
              },
          ],
          [
            'attribute' => 'bookId',
            'value' => function ($dataProvider) {
                $bookName = Book::find()->where(['bookId'=>$dataProvider->bookId])->One();
                return $bookName->bookName;
            },
        ],

            'borrowDate',
            'expectedReturnDate',
            'actualReturnDate',
            ['class' => 'yii\grid\ActionColumn'],

            
        ],
    ]); ?>


</div>
