<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use common\models\User;
use yii\helpers\ArrayHelper;
use frontend\models\Book;
use frontend\models\borrowedbook;
/* @var $this yii\web\View */
/* @var $model frontend\models\Borrowedbook */
/* @var $form yii\widgets\ActiveForm */
$student = ArrayHelper::map(User::find()->all(), 'id', 'username');
$book=ArrayHelper::map(Book::find()->all(),'bookId', 'bookName');
?>
<div class="borrowedbook-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'studentId')->dropDownlist($student) ?>

    <?= $form->field($model, 'bookId')->dropDownlist($book) ?>

    <?= $form->field($model, 'borrowDate')->textInput() ?>

    <?= $form->field($model, 'expectedReturnDate')->textInput() ?>

    <?= $form->field($model, 'actualReturnDate')->textInput() ?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
