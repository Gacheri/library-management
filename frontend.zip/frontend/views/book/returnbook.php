<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model frontend\models\Book */
/* @var $form ActiveForm */
?>
<div class="returnbook">

<div class="modal-content">
              <div class="modal-body">
                <p>Are you sure you want to return this book</p>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Yes</button>
                <button type="button" class="btn btn-outline">No</button>
              </div>
            </div>
</div>
<!-- returnbook -->
